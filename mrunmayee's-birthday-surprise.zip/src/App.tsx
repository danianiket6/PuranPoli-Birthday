import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import confetti from 'canvas-confetti';
import { Heart, Volume2, VolumeX } from 'lucide-react';
import { cn } from './lib/utils';

function FloatingHearts() {
  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
      {[...Array(25)].map((_, i) => (
        <motion.div
          key={i}
          initial={{ 
            y: '100vh', 
            x: `${Math.random() * 100}vw`,
            scale: Math.random() * 0.5 + 0.5,
            opacity: Math.random() * 0.5 + 0.2
          }}
          animate={{ 
            y: '-10vh',
            x: `${Math.random() * 100}vw`,
          }}
          transition={{ 
            duration: Math.random() * 10 + 10, 
            repeat: Infinity,
            ease: "linear",
            delay: Math.random() * 10
          }}
          className="absolute text-rose-400/40"
        >
          <Heart fill="currentColor" size={Math.random() * 20 + 15} />
        </motion.div>
      ))}
    </div>
  );
}

function OpeningScreen({ onNext }: { onNext: () => void }) {
  const [noPosition, setNoPosition] = useState({ x: 0, y: 0 });

  const moveNoButton = () => {
    const x = Math.random() * 250 - 125;
    const y = Math.random() * 250 - 125;
    setNoPosition({ x, y });
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 1.2 }}
      className="flex flex-col items-center justify-center space-y-12 text-center w-full"
    >
      <h1 className="text-4xl md:text-6xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-rose-500 to-pink-600 drop-shadow-sm px-4">
        Hey Mrunmayee… Ready for a surprise? ❤️
      </h1>
      <div className="flex items-center justify-center relative w-full max-w-sm h-32">
        <button
          onClick={onNext}
          className="px-10 py-4 bg-gradient-to-r from-rose-500 to-pink-500 hover:from-rose-600 hover:to-pink-600 text-white rounded-full font-bold text-2xl shadow-xl hover:shadow-2xl transition-all hover:scale-110 active:scale-95 z-10 absolute"
          style={{ left: '20%' }}
        >
          YES 😍
        </button>
        <motion.button
          animate={{ x: noPosition.x, y: noPosition.y }}
          onHoverStart={moveNoButton}
          onClick={moveNoButton}
          onTouchStart={moveNoButton}
          className="px-10 py-4 bg-white text-rose-500 border-2 border-rose-200 rounded-full font-bold text-2xl shadow-md absolute z-20"
          style={{ right: '20%' }}
        >
          NO 😜
        </motion.button>
      </div>
    </motion.div>
  );
}

function QuestionScreen({ question, onNext }: { question: string, onNext: () => void }) {
  const [noPosition, setNoPosition] = useState({ x: 0, y: 0 });

  const moveNoButton = () => {
    const x = Math.random() * 250 - 125;
    const y = Math.random() * 250 - 125;
    setNoPosition({ x, y });
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: 50 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -50 }}
      className="flex flex-col items-center justify-center space-y-10 text-center px-4 w-full"
    >
      <h2 className="text-3xl md:text-5xl font-bold text-rose-600 drop-shadow-sm leading-tight">
        {question}
      </h2>
      <div className="flex items-center justify-center relative w-full max-w-sm h-32">
        <button
          onClick={onNext}
          className="px-10 py-4 bg-gradient-to-r from-rose-500 to-pink-500 hover:from-rose-600 hover:to-pink-600 text-white rounded-full font-bold text-2xl shadow-xl hover:shadow-2xl transition-all hover:scale-110 active:scale-95 z-10 absolute"
          style={{ left: '20%' }}
        >
          YES 😍
        </button>
        <motion.button
          animate={{ x: noPosition.x, y: noPosition.y }}
          onHoverStart={moveNoButton}
          onClick={moveNoButton}
          onTouchStart={moveNoButton}
          className="px-10 py-4 bg-white text-rose-500 border-2 border-rose-200 rounded-full font-bold text-2xl shadow-md absolute z-20"
          style={{ right: '20%' }}
        >
          NO 😜
        </motion.button>
      </div>
    </motion.div>
  );
}

function MiniGame({ onNext }: { onNext: () => void }) {
  const [result, setResult] = useState<string | null>(null);

  const handleOptionClick = () => {
    setResult("Correct answer is ME ❤️");
    setTimeout(() => {
      onNext();
    }, 2500);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 1.1 }}
      className="flex flex-col items-center justify-center space-y-8 text-center w-full max-w-md px-4 relative"
    >
      <h2 className="text-3xl md:text-4xl font-bold text-rose-600 mb-4">
        Guess who likes you? 😏
      </h2>
      
      <div className="flex flex-col w-full gap-4">
        {["Me 😌", "Someone special 😉", "Secret admirer 😏"].map((opt, i) => (
          <motion.button
            key={i}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={handleOptionClick}
            className="w-full py-4 bg-white/80 backdrop-blur-sm border-2 border-rose-200 text-rose-700 rounded-2xl font-semibold text-xl shadow-sm hover:bg-rose-50 transition-colors"
          >
            {opt}
          </motion.button>
        ))}
      </div>

      <AnimatePresence>
        {result && (
          <motion.div
            initial={{ opacity: 0, scale: 0.5, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            className="absolute inset-0 flex items-center justify-center bg-rose-100/95 backdrop-blur-md z-10 rounded-3xl"
          >
            <h3 className="text-4xl font-bold text-rose-600 drop-shadow-md px-4">
              {result}
            </h3>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

const messages = [
  "Actually… mala kahi sangaycha hota…",
  "thoda awkward aahe…",
  "pan sangto…",
  "I think… I like you ❤️"
];

function TypingScene({ onNext }: { onNext: () => void }) {
  const [visibleMessages, setVisibleMessages] = useState<number>(0);
  const [isTyping, setIsTyping] = useState(true);

  useEffect(() => {
    if (visibleMessages < messages.length) {
      setIsTyping(true);
      const typingTimer = setTimeout(() => {
        setIsTyping(false);
        setVisibleMessages(prev => prev + 1);
      }, 2000);
      return () => clearTimeout(typingTimer);
    } else {
      const nextTimer = setTimeout(() => {
        onNext();
      }, 3000);
      return () => clearTimeout(nextTimer);
    }
  }, [visibleMessages, onNext]);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="flex flex-col w-full max-w-md bg-white/70 backdrop-blur-md rounded-3xl p-6 shadow-xl h-[450px] mx-4"
    >
      <div className="flex items-center gap-4 border-b border-rose-200 pb-4 mb-4">
        <div className="w-12 h-12 bg-gradient-to-br from-rose-400 to-pink-500 rounded-full flex items-center justify-center text-white font-bold text-xl shadow-inner">
          S
        </div>
        <div>
          <h3 className="font-bold text-gray-800 text-lg">Someone Special</h3>
          <p className="text-sm text-green-500 font-medium">online</p>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto space-y-4 flex flex-col justify-end pb-2">
        <AnimatePresence>
          {messages.slice(0, visibleMessages).map((msg, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 10, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              className="self-start bg-white border border-rose-100 text-gray-800 px-5 py-3 rounded-2xl rounded-tl-none shadow-sm max-w-[85%] text-lg"
            >
              {msg}
            </motion.div>
          ))}
          {isTyping && visibleMessages < messages.length && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="self-start bg-white border border-rose-100 text-gray-500 px-5 py-4 rounded-2xl rounded-tl-none shadow-sm flex items-center gap-1.5"
            >
              <span className="w-2.5 h-2.5 bg-rose-300 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
              <span className="w-2.5 h-2.5 bg-rose-300 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
              <span className="w-2.5 h-2.5 bg-rose-300 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}

function PhotoReveal({ onNext }: { onNext: () => void }) {
  const [isRevealed, setIsRevealed] = useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, y: -50 }}
      className="flex flex-col items-center justify-center space-y-8 px-4"
    >
      <h2 className="text-3xl md:text-4xl font-bold text-rose-600 text-center drop-shadow-sm">
        {isRevealed ? "You are so beautiful ❤️" : "Tap to reveal a beautiful girl ✨"}
      </h2>
      
      <motion.div
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        onClick={() => {
          if (!isRevealed) {
            setIsRevealed(true);
            setTimeout(() => onNext(), 4000);
          }
        }}
        className="relative cursor-pointer rounded-3xl overflow-hidden shadow-2xl ring-4 ring-rose-200 bg-rose-100"
      >
        <img 
          src="/mrunmayee.jpg" 
          alt="Mrunmayee"
          className={cn(
            "w-72 h-96 object-cover transition-all duration-1000 ease-in-out",
            isRevealed ? "blur-0 scale-100" : "blur-xl scale-110"
          )}
          onError={(e) => {
            (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1518621736915-f3b1c41bfd00?q=80&w=1000&auto=format&fit=crop";
          }}
        />
        {!isRevealed && (
          <div className="absolute inset-0 flex items-center justify-center bg-rose-500/20 backdrop-blur-sm">
            <Heart className="w-16 h-16 text-white animate-pulse" fill="currentColor" />
          </div>
        )}
      </motion.div>
    </motion.div>
  );
}

function FinalScreen() {
  const [showSecret, setShowSecret] = useState(false);
  const [noPosition, setNoPosition] = useState({ x: 0, y: 0 });
  const [accepted, setAccepted] = useState(false);

  const moveNoButton = () => {
    const x = Math.random() * 250 - 125;
    const y = Math.random() * 250 - 125;
    setNoPosition({ x, y });
  };

  useEffect(() => {
    const duration = 5 * 1000;
    const animationEnd = Date.now() + duration;
    const defaults = { startVelocity: 30, spread: 360, ticks: 60, zIndex: 0 };

    const randomInRange = (min: number, max: number) => Math.random() * (max - min) + min;

    const interval: any = setInterval(function() {
      const timeLeft = animationEnd - Date.now();

      if (timeLeft <= 0) {
        return clearInterval(interval);
      }

      const particleCount = 50 * (timeLeft / duration);
      confetti({
        ...defaults, particleCount,
        origin: { x: randomInRange(0.1, 0.3), y: Math.random() - 0.2 },
        colors: ['#f43f5e', '#ec4899', '#fdf2f8', '#fda4af']
      });
      confetti({
        ...defaults, particleCount,
        origin: { x: randomInRange(0.7, 0.9), y: Math.random() - 0.2 },
        colors: ['#f43f5e', '#ec4899', '#fdf2f8', '#fda4af']
      });
    }, 250);

    return () => clearInterval(interval);
  }, []);

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      className="flex flex-col items-center justify-center space-y-10 text-center max-w-2xl px-4"
    >
      <motion.h1 
        initial={{ y: -20, opacity: 0, scale: 0.9 }}
        animate={{ y: [0, -10, 0], opacity: 1, scale: 1 }}
        transition={{ 
          y: { duration: 2, repeat: Infinity, ease: "easeInOut" },
          opacity: { duration: 0.8 },
          scale: { duration: 0.8, type: "spring", bounce: 0.5 }
        }}
        className="text-5xl md:text-7xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-rose-500 to-pink-600 drop-shadow-sm"
      >
        Happy Birthday Mrunmayee ❤️
      </motion.h1>
      
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.5, duration: 0.8, type: "spring" }}
        className="space-y-6 text-xl md:text-2xl text-rose-800 font-medium bg-white/50 p-8 rounded-3xl backdrop-blur-md shadow-lg border border-rose-100"
      >
        <motion.p 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 1, duration: 0.8 }}
          className="leading-relaxed"
        >
          "The day you were born, the world became more beautiful for me."
        </motion.p>
        <motion.p 
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 1.5, duration: 0.8 }}
          className="leading-relaxed"
        >
          "You are not just special… you are my favorite feeling ❤️"
        </motion.p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 2 }}
        className="pt-8 w-full flex flex-col items-center"
      >
        {!showSecret ? (
          <button
            onClick={() => setShowSecret(true)}
            className="text-lg text-rose-500 hover:text-rose-700 underline underline-offset-4 transition-colors font-medium"
          >
            Click here for a secret…
          </button>
        ) : !accepted ? (
          <motion.div
            initial={{ opacity: 0, scale: 0.5, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            className="bg-white/80 backdrop-blur-md px-4 py-8 rounded-3xl shadow-2xl border-2 border-rose-200 w-full max-w-md flex flex-col items-center space-y-8"
          >
            <h3 className="text-3xl md:text-4xl font-bold text-rose-600 drop-shadow-sm">
              Will you go out with me someday? ❤️
            </h3>
            <div className="flex items-center justify-center relative w-full h-32">
              <button
                onClick={() => setAccepted(true)}
                className="px-8 py-3 bg-gradient-to-r from-rose-500 to-pink-500 hover:from-rose-600 hover:to-pink-600 text-white rounded-full font-bold text-xl shadow-xl hover:shadow-2xl transition-all hover:scale-110 active:scale-95 z-10 absolute"
                style={{ left: '10%' }}
              >
                YES 😍
              </button>
              <motion.button
                animate={{ x: noPosition.x, y: noPosition.y }}
                onHoverStart={moveNoButton}
                onClick={moveNoButton}
                onTouchStart={moveNoButton}
                className="px-8 py-3 bg-white text-rose-500 border-2 border-rose-200 rounded-full font-bold text-xl shadow-md absolute z-20"
                style={{ right: '10%' }}
              >
                NO 😜
              </motion.button>
            </div>
          </motion.div>
        ) : (
          <motion.div
            initial={{ opacity: 0, scale: 0.5, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            className="bg-gradient-to-r from-rose-500 to-pink-500 text-white px-8 py-8 rounded-3xl shadow-2xl border-4 border-white/20"
          >
            <h3 className="text-3xl md:text-4xl font-bold drop-shadow-md">
              Yay! I can't wait! 🥰❤️
            </h3>
          </motion.div>
        )}
      </motion.div>
    </motion.div>
  );
}

const questions = [
  "Do you know someone special? 😉",
  "Is today the most beautiful girl's birthday? 🎂",
  "Are you ready to smile? 😊",
  "Do you believe in cute surprises? 💖",
  "Do you feel something special between us? 💖"
];

export default function App() {
  const [step, setStep] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const audioRef = useRef<HTMLAudioElement>(null);

  const handleNext = () => {
    if (step === 0 && !isPlaying && audioRef.current) {
      audioRef.current.play().then(() => setIsPlaying(true)).catch(e => console.log("Audio play failed:", e));
    }
    setStep(s => s + 1);
  };

  const toggleAudio = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
      } else {
        audioRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-100 via-rose-50 to-pink-100 flex items-center justify-center p-4 overflow-hidden relative font-sans">
      <FloatingHearts />
      
      <audio 
        ref={audioRef}
        src="https://cdn.pixabay.com/download/audio/2022/05/27/audio_1808fbf07a.mp3?filename=romantic-piano-112194.mp3" 
        loop
        className="hidden"
      />

      <button 
        onClick={toggleAudio}
        className="fixed top-4 right-4 z-50 p-3 bg-white/50 backdrop-blur-md rounded-full text-rose-500 hover:bg-white/80 transition-colors shadow-sm border border-rose-100"
      >
        {isPlaying ? <Volume2 size={24} /> : <VolumeX size={24} />}
      </button>

      <div className="relative z-10 w-full max-w-4xl flex items-center justify-center min-h-[70vh]">
        <AnimatePresence mode="wait">
          {step === 0 && <OpeningScreen key="step0" onNext={handleNext} />}
          {step > 0 && step <= 5 && (
            <QuestionScreen 
              key={`step${step}`} 
              question={questions[step - 1]} 
              onNext={handleNext} 
            />
          )}
          {step === 6 && <MiniGame key="step6" onNext={handleNext} />}
          {step === 7 && <TypingScene key="step7" onNext={handleNext} />}
          {step === 8 && <PhotoReveal key="step8" onNext={handleNext} />}
          {step === 9 && <FinalScreen key="step9" />}
        </AnimatePresence>
      </div>
    </div>
  );
}
